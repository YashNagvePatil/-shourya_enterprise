import productDao from "../dao/product.dao.js";
import { uploadMultipleToCloudinary } from "../services/storage.service.js";
import productModel from "../models/product.model.js";
import inventryModel from "../models/inventry.model.js";
import { clearCachePattern } from "../config/cacheRedis.js";





// ==========================================
// Create Product Controller (With Detailed Debug Logging)
// ==========================================

export const createProduct = async (req, res) => {
  const timestamp = new Date().toISOString();
  console.log(`\n========================================`);
  console.log(`[${timestamp}] 🚀 [CREATE PRODUCT INITIATED]`);
  console.log(`[DEBUG] Route Path: ${req.originalUrl}`);
  console.log(`[DEBUG] Authenticated User:`, req.user ? { id: req.user._id, role: req.user.role } : "None");
  console.log(`[DEBUG] Received req.body keys:`, Object.keys(req.body || {}));

  try {
    const {
      name,
      sku,
      description,
      shortDescription,
      category,
      brand,
      mrp,
      price,
      bv,
      pv,
      directCommission,
      stock,
      isActivationPackage,
      packageTier,
      gstPercentage,
      images,
     
    } = req.body;

    // ------------------------------------------
    // 1. Mandatory Validations Check
    // ------------------------------------------
    console.log(`[DEBUG] Step 1: Validating mandatory fields...`);
    if (!name || !sku || !description || !category || mrp === undefined || price === undefined) {
      const missingFields = [];
      if (!name) missingFields.push("name");
      if (!sku) missingFields.push("sku");
      if (!description) missingFields.push("description");
      if (!category) missingFields.push("category");
      if (mrp === undefined) missingFields.push("mrp");
      if (price === undefined) missingFields.push("price");

      console.warn(`[DEBUG VALIDATION FAILED] Missing required fields:`, missingFields);
      return res.status(400).json({
        success: false,
        message: `Missing required fields: ${missingFields.join(", ")}`,
        missingFields,
      });
    }

    // ------------------------------------------
    // 2. Parse & Validate Numeric Pricing
    // ------------------------------------------
    console.log(`[DEBUG] Step 2: Parsing pricing numbers (MRP: ${mrp}, Price: ${price})...`);
    const parsedMrp = Number(mrp);
    const parsedPrice = Number(price);

    if (isNaN(parsedMrp) || isNaN(parsedPrice)) {
      console.warn(`[DEBUG VALIDATION FAILED] Non-numeric pricing provided. Parsed MRP: ${parsedMrp}, Parsed Price: ${parsedPrice}`);
      return res.status(400).json({
        success: false,
        message: "MRP and Price must be valid numbers",
      });
    }

    if (parsedPrice > parsedMrp) {
      console.warn(`[DEBUG VALIDATION FAILED] Selling Price (${parsedPrice}) exceeds MRP (${parsedMrp})`);
      return res.status(400).json({
        success: false,
        message: "Selling Price (DP) cannot be greater than MRP Rate",
      });
    }

    // ------------------------------------------
    // 3. Unique SKU Check
    // ------------------------------------------
    const formattedSku = sku.toUpperCase().trim();
    console.log(`[DEBUG] Step 3: Checking database for unique SKU '${formattedSku}'...`);
    
    const existingProduct = await productDao.findBySku(formattedSku);
    if (existingProduct) {
      console.warn(`[DEBUG VALIDATION FAILED] Duplicate SKU found: '${formattedSku}'`);
      return res.status(400).json({
        success: false,
        message: `Product SKU '${formattedSku}' already exists. SKU must be unique.`,
      });
    }

    // ------------------------------------------
    // 4. Handle Base64 Uploads to Cloudinary
    // ------------------------------------------
    let uploadedImages = [];
    if (images && Array.isArray(images) && images.length > 0) {
      console.log(`[DEBUG] Step 4: Processing ${images.length} image(s) for Cloudinary...`);

      if (images.length > 5) {
        console.warn(`[DEBUG VALIDATION FAILED] Image count (${images.length}) exceeds 5 limit.`);
        return res.status(400).json({
          success: false,
          message: "You can upload a maximum of 5 images per product.",
        });
      }

      // Log type and string size of first item for Base64 format verification
      console.log(`[DEBUG] Sample image data type: ${typeof images[0]}, String length: ${images[0]?.length || 0}`);
      
      try {
        uploadedImages = await uploadMultipleToCloudinary(images, "mlm_products");
        console.log(`[DEBUG] Cloudinary Upload Success. Received ${uploadedImages.length} image objects.`);
      } catch (cloudinaryErr) {
        console.error(`❌ [CLOUDINARY UPLOAD ERROR]:`, cloudinaryErr.message);
        return res.status(500).json({
          success: false,
          message: "Failed to upload images to Cloudinary",
          error: cloudinaryErr.message,
        });
      }
    } else {
      console.log(`[DEBUG] Step 4: No images provided in request body.`);
    }

    // ------------------------------------------
    // 5. Pre-Calculated Fields & Payload Assembly
    // ------------------------------------------
    console.log(`[DEBUG] Step 5: Assembling database payload...`);
    const discountAmount = parsedMrp - parsedPrice;
    const discountPercentage = parsedMrp > 0 ? Math.round((discountAmount / parsedMrp) * 100) : 0;

    const productPayload = {
      name: name.trim(),
      sku: formattedSku,
      description,
      shortDescription: shortDescription || "",
      category: category.trim(),
      brand: brand || "Generic",
      mrp: parsedMrp,
      price: parsedPrice,
      bv: Number(bv || 0),
      pv: Number(pv || 0),
      directCommission: Number(directCommission || 0),
      stock: Number(stock || 0),
      images: uploadedImages,
      isActivationPackage: isActivationPackage === "true" || isActivationPackage === true,
      packageTier: packageTier || "None",
      gstPercentage: Number(gstPercentage || 18),
    };

    console.log(`[DEBUG] Payload assembled:`, JSON.stringify(productPayload, null, 2));

    // ------------------------------------------
    // 6. Save Product via DAO
    // ------------------------------------------
    console.log(`[DEBUG] Step 6: Persisting product to Mongo Database via DAO...`);
    const newProduct = await productDao.createProduct(productPayload);
    console.log(`✅ [PRODUCT CREATED SUCCESS] ID: ${newProduct._id}`);

    // Auto-create matching Inventory entry for the new product
    try {
      await inventryModel.create({
        product: newProduct._id,
        sku: newProduct.sku,
        quantity: newProduct.stock || 0,
        costPrice: newProduct.price || 0,
        wholesalerPrice: newProduct.price || 0,
      });
      console.log(`✅ [INVENTORY INITIALIZED] For product ID: ${newProduct._id}`);
    } catch (invErr) {
      console.warn(`⚠️ [INVENTORY INITIALIZE WARNING]:`, invErr.message);
    }

    // Invalidate product cache in Redis so users get fresh product list immediately
    await clearCachePattern("products:*");

    // ------------------------------------------
    // 7. Success Response
    // ------------------------------------------
    return res.status(201).json({
      success: true,
      message: "Product created successfully with Cloudinary images!",
      meta: {
        discountAmount,
        discountPercentage: `${discountPercentage}%`,
      },
      data: newProduct,
    });
  } catch (error) {
    // ------------------------------------------
    // Detailed Error Catch & Categorization
    // ------------------------------------------
    console.error(`\n❌ [CREATE PRODUCT CATCH ERROR LOGGED]`);
    console.error(`[ERROR NAME]:`, error.name);
    console.error(`[ERROR MESSAGE]:`, error.message);
    console.error(`[STACK TRACE]:\n`, error.stack);

    // Mongoose Validation Error (e.g. schema types or min/max constraints fail)
    if (error.name === "ValidationError") {
      const mongooseErrors = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: "Database Validation Failed",
        errors: mongooseErrors,
      });
    }

    // Mongo Duplicate Key Error
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Duplicate field value entered in database",
        duplicateFields: error.keyValue,
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Product Creation Failed",
      debugInfo: {
        errorName: error.name,
        stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
    });
  }
};


export const getAllProducts = async (req, res) => {
  try {
    const { category, search, page = 1, limit = 12 ,forFranchiseSupply} = req.query;

    const query = {};

    if (forFranchiseSupply === "true") {
      query.isAvailableForFranchiseSupply = true;
    }
  


    if (category && category !== "ALL") {
      query.category = category;
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { sku: { $regex: search, $options: "i" } },
      ];
    }

    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;

    const [products, totalProducts] = await Promise.all([
      productModel.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      productModel.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      count: products.length,
      totalProducts,
      totalPages: Math.ceil(totalProducts / limitNum),
      currentPage: pageNum,
      data: products,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch products",
      error: error.message,
    });
  }
};

export const getProductDetails = async (req, res) => {
  try {
    const { id } = req.params;

    // 1. Fetch target product details
    const product = await productModel.findById(id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    // 2. Fetch related products in the same category (excluding current product)
    const relatedProducts = await productModel.find({
      category: product.category,
      _id: { $ne: product._id },
    })
      .limit(4)
      .sort({ createdAt: -1 })
      .lean();

    res.status(200).json({
      success: true,
      data: {
        product,
        relatedProducts,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching product details",
      error: error.message,
    });
  }
};